import React from 'react';

function Projects() {
  return (
    <section className="Projects">
        <br></br>
      <h2>Experience</h2>
      <div className="project">
        <h3>Portfolio Website</h3>
        <p>
          This very portfolio website you are visiting! A showcase of my web development and design skills. It features a dark-themed, gradient design with information about me, my skills, projects, and more. Built using React, HTML, and CSS.
        </p>
        <p>Technologies: React, HTML, CSS</p>
        <a href="#">GitHub Repo</a>
        <h3>Volunteer in Microsoft Student Chapter -VITAP</h3>
        <h3>Working knowledge in Android Studio</h3>
      </div>
    </section>
  );
}

export default Projects;
