import React from 'react';
import './Skills.css';

function Skills() {
  return (
    <section className="skills">
        <br></br>
      <h2>Skills</h2>
      <ul>
        <li>Web Development</li>
        <li>Mobile Application Development</li>
        <li>JavaScript</li>
        <li>React</li>
        <li>Node.js</li>
        <li>Data Analysis using R</li>
      </ul>
    </section>
  );
}

export default Skills;
