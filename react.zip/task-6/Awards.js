import React from 'react';
import './Awards.css';

function Awards() {
  return (
    <section className="awards">
                <br></br>
      <h2>Certifications</h2>
      <ul>
        <li>Java Programmer(HackerRank)</li>
        <li>Completeion of DataAnalytics Course (Coursera)</li>
        <li>Python (Simplilearn)</li>
      </ul>
    </section>
  );
}

export default Awards;
