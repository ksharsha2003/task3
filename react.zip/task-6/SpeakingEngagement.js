import React from 'react';
import './SpeakingEngagement.css';

function SpeakingEngagement() {
  return (
    <section className="speaking-engagement">
              <br></br>
      <h2>Public Speaking Engagements</h2>
      
        <li>Web Development Conference (Speaker, 2022)</li>
        <li>Tech Webinar (Panelist, 2022)</li>
        <li>UX Design Workshop (Presenter, 2022)</li>
      
    </section>
  );
}

export default SpeakingEngagement;
